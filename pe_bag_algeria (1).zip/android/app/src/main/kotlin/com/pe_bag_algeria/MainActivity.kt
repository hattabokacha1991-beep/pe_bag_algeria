package com.pe_bag_algeria

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
